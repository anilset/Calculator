
import java.util.Scanner;
import kata.calc.model.Input;
import kata.calc.service.Calculation;

public class Main {
    public static void main(String[] args) throws RuntimeException {
        Scanner scanner = new Scanner(System.in);
        Input input = new Input(scanner.nextLine());
        Calculation calculation = new Calculation(input);
            System.out.println(calculation.getResult());
    }
}