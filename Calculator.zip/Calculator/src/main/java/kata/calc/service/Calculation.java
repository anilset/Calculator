package kata.calc.service;
import kata.calc.model.Input;
public class Calculation {
    private Input input;
    public Calculation (Input input) {
        this.input = input;
    }
    public String getResult() {
        int result = 0;
        switch (input.getOperator()) {
            case "+":
                result += (input.getA() + input.getB());
                break;
            case "-":
                result += (input.getA() - input.getB());
                break;
            case "*":
                result += (input.getA() * input.getB());
                break;
            case "/":
                result += (input.getA() / input.getB());
                //result += Math.round(input.getA() * 100.0 / input.getB()/ 100.0); // непонятно как именно нужно округлять из задания
                break;
            default :
                System.out.println("Данный оператор не поддерживается");
        } return Integer.toString(result);
    }
}


