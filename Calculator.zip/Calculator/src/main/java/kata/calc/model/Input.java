package kata.calc.model;

public class Input {
    private String input;
    private String[] strings;
    private byte a;
    private byte b;
    private String operator;

    public Input(String input) {

        this.input = input;
        try {
            String[] strings = input.split(" ");
            this.a = Byte.parseByte(strings[0]);
            this.b = Byte.parseByte(strings[2]);
            this.operator = strings[1];
        } catch (Exception exception) {
        System.out.println("Формат ввода данных: X + Y, где X и Y - целые числа от -10 до 10");
            System.out.println("Числа должны быть отделены пробелами от знака. Пожалуйста, введите валидные данные.");
        }
    }

    /* public String[] getInput (String input){
            String[] strings = input.split(" ");
            return strings;
        } */

        public byte getA () throws ArrayIndexOutOfBoundsException {
            return a;
        }

        public byte getB () throws ArrayIndexOutOfBoundsException {
            return b;
        }

        public String getOperator () throws ArrayIndexOutOfBoundsException {
            return operator;
        }
    }
